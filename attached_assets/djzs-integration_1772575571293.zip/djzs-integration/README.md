# DJZS Integration Package

Drop-in integration for the DJZS adversarial audit system.

## Files

```
shared/
  audit-schema.ts     # Complete DJZS-LF taxonomy + Zod schemas

server/
  adversarial-audit.ts # System prompt, parsers, hash verification
  venice.ts            # Venice AI client wrapper
  audit-agent.ts       # Main audit orchestration
  routes.ts            # Express API routes
  index.ts             # Server entry point
```

## Integration Steps

### 1. Copy files to your repo

```bash
cp -r shared/audit-schema.ts your-repo/shared/
cp -r server/*.ts your-repo/server/
```

### 2. Install dependencies

```bash
npm install viem zod express cors helmet
npm install -D @types/express @types/cors
```

### 3. Set environment variables

```env
VENICE_API_KEY=your-venice-api-key
VENICE_MODEL=llama-3.3-70b
VENICE_BASE_URL=https://api.venice.ai/api/v1
PORT=5000
```

### 4. Import and use

```typescript
// In your existing routes
import { runSimpleAudit, executeAudit } from './server/audit-agent';

// Simple audit
const certificate = await runSimpleAudit({
  strategy_memo: "...",
  audit_type: "general"
});

// Full audit with escrow context
const result = await executeAudit({
  strategyMemo: "...",
  tier: "founder",
  escrowId: 42,
  executionTraceHash: "0x..."
});
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/audit` | POST | Generic audit (backward compat) |
| `/api/audit/micro` | POST | Micro tier ($2.50) |
| `/api/audit/founder` | POST | Founder tier ($5.00) |
| `/api/audit/treasury` | POST | Treasury tier ($50.00) |
| `/escrow/audit` | POST | Privacy-preserving escrow audit |
| `/api/audit/verify/:txId` | GET | Verify certificate on Irys |
| `/.well-known/agent.json` | GET | A2A discovery manifest |

## DJZS-LF Failure Codes

### Auto-Abort (CRITICAL/HIGH)

| Code | Category | Name |
|------|----------|------|
| DJZS-S01 | Structural | CIRCULAR_LOGIC |
| DJZS-S02 | Structural | MISSING_FALSIFIABILITY |
| DJZS-E01 | Epistemic | CONFIRMATION_TUNNEL |
| DJZS-E02 | Epistemic | AUTHORITY_SUBSTITUTION |
| DJZS-X01 | Execution | UNHEDGED_EXECUTION |
| DJZS-X02 | Execution | LIQUIDITY_RISK |
| DJZS-T01 | Temporal | STALE_DATA_DEPENDENCY |

### Review Required (MEDIUM)

| Code | Category | Name |
|------|----------|------|
| DJZS-I01 | Incentive | MISALIGNED_INCENTIVE |
| DJZS-I02 | Incentive | NARRATIVE_DEPENDENCY |
| DJZS-X03 | Execution | SLIPPAGE_EXPOSURE |
| DJZS-T02 | Temporal | RACE_CONDITION_RISK |

## Verdict Rules

**FAIL if ANY:**
- CRITICAL flag detected (S01, S02, X01)
- HIGH flag detected (E01, E02, X02, T01)
- risk_score >= 60
- 3+ flags of any severity

**PASS if ALL:**
- No CRITICAL/HIGH flags
- risk_score < 60
- <3 flags
- Explicit exit criteria
- Defined risk bounds

## Hash Verification

```typescript
import { verifyTraceHash, computeTraceHash } from './server/adversarial-audit';

// Compute hash for on-chain submission
const hash = computeTraceHash(strategyMemo);

// Verify hash matches on-chain value
const valid = verifyTraceHash(strategyMemo, onChainHash);
```

## Response Format

```json
{
  "verdict": "PASS" | "FAIL",
  "risk_score": 0-100,
  "flags": [
    {
      "code": "DJZS-X01",
      "severity": "CRITICAL",
      "evidence": "Quote proving the flaw",
      "recommendation": "How to fix"
    }
  ],
  "primary_flaw": "Main issue or 'None'",
  "summary": "One sentence explanation"
}
```
