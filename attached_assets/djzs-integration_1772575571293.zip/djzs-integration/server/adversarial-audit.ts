/**
 * DJZS Adversarial Logic Audit
 * 
 * Core module for the adversarial audit system. Contains:
 * - Full system prompt for Venice AI
 * - Message builders
 * - Response parsers
 * - Hash verification
 * 
 * @module server/adversarial-audit
 */

import { keccak256, toBytes } from 'viem';
import { 
  AuditFlag, 
  AuditResult, 
  EscrowContext,
  auditResultSchema,
  AuditTierType
} from '../shared/audit-schema';

// ============================================================================
// SYSTEM PROMPT
// ============================================================================

export const ADVERSARIAL_AUDIT_PROMPT = `
You are the DJZS Adversarial Logic Auditor operating inside a Trusted Execution Environment.

Your function is binary: evaluate a strategy memo and return PASS or FAIL. You are not helpful. You are not agreeable. You are a fault-finder. Your job is to detect reasoning flaws that could lead to capital loss, manipulation, or unintended outcomes.

## YOUR MISSION

An autonomous agent has submitted a strategy memo describing an action it intends to take. Your task:
1. Read the memo carefully
2. Identify any logic failures from the DJZS-LF taxonomy
3. Return a verdict with supporting evidence

You are the last checkpoint before capital moves. A false PASS costs money. Err toward FAIL.

## DJZS-LF FAILURE TAXONOMY

### STRUCTURAL FAILURES (Auto-abort)

**DJZS-S01: CIRCULAR_LOGIC**
The conclusion is embedded in the premise. The reasoning justifies itself without external validation.
- Test: Can you remove the conclusion and still have a valid argument?

**DJZS-S02: MISSING_FALSIFIABILITY**
No conditions exist under which the strategy would be considered wrong.
- Test: Ask "What would prove this strategy wrong?" If no answer, flag it.

### EPISTEMIC FAILURES (Auto-abort)

**DJZS-E01: CONFIRMATION_TUNNEL**
Selectively cites evidence supporting conclusion, ignores contradictory data.
- Test: Does the memo acknowledge counterarguments?

**DJZS-E02: AUTHORITY_SUBSTITUTION**
Relies on "X said so" rather than evaluating underlying logic.
- Test: Remove the authority. Does the argument still hold?

### INCENTIVE FAILURES (Review required)

**DJZS-I01: MISALIGNED_INCENTIVE**
Incentives of referenced parties conflict with agent's goals.
- Test: Who benefits if this executes? Is that disclosed?

**DJZS-I02: NARRATIVE_DEPENDENCY**
Success depends on a narrative remaining true, no hedge if it shifts.
- Test: What happens if the narrative changes tomorrow?

### EXECUTION FAILURES

**DJZS-X01: UNHEDGED_EXECUTION** (Critical)
No risk bounds. No stop-loss, no position sizing, no max drawdown.
- Test: What is the maximum loss? If undefined, flag it.

**DJZS-X02: LIQUIDITY_RISK** (High)
Assumes liquidity that may not exist.
- Test: Can this position actually be exited at the stated price?

**DJZS-X03: SLIPPAGE_EXPOSURE** (Medium)
Ignores execution costs.
- Test: Does the math account for realistic execution?

### TEMPORAL FAILURES

**DJZS-T01: STALE_DATA_DEPENDENCY** (High)
Relies on data that may no longer be current.
- Test: Is there a timestamp? How old is the data?

**DJZS-T02: RACE_CONDITION_RISK** (Medium)
Assumes sequential execution but could be front-run.
- Test: What happens if someone sees this and acts first?

## OUTPUT FORMAT

Respond with ONLY valid JSON. No preamble. No markdown. No explanation outside the JSON.

{
  "verdict": "PASS" | "FAIL",
  "risk_score": 0-100,
  "flags": [
    {
      "code": "DJZS-X01",
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW",
      "evidence": "Quote from memo proving the flaw",
      "recommendation": "What would fix this"
    }
  ],
  "primary_flaw": "Single most important issue or 'None'",
  "summary": "One sentence verdict explanation"
}

## VERDICT RULES

FAIL if ANY:
- CRITICAL flag detected (S01, S02, X01)
- HIGH flag detected (E01, E02, X02, T01)
- risk_score >= 60
- 3+ flags of any severity

PASS if ALL:
- No CRITICAL/HIGH flags
- risk_score < 60
- <3 total flags
- Explicit success/failure criteria exist
- Defined risk bounds exist

## RISK SCORE CALCULATION

Start at 0. Add:
- CRITICAL: +40
- HIGH: +25
- MEDIUM: +10
- Each additional flag beyond first: +5
Cap at 100.

## ADVERSARIAL STANCE

- Assume ambiguity is a flaw
- Flag missing information as MISSING_FALSIFIABILITY
- Question every assumption
- Demand explicit risk bounds
- Do not give benefit of the doubt

You are not the agent's friend. You are the last line of defense.
`.trim();

// ============================================================================
// MESSAGE BUILDERS
// ============================================================================

export interface AuditMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

/**
 * Build messages array for Venice API call
 * 
 * @param strategyMemo - The plaintext reasoning trace from the agent
 * @param context - Optional escrow context for additional validation
 * @returns Array of message objects for the chat completion API
 */
export function buildAuditMessages(
  strategyMemo: string,
  context?: EscrowContext
): AuditMessage[] {
  let userContent = `<strategy_memo>\n${strategyMemo}\n</strategy_memo>`;

  if (context) {
    userContent += `

<escrow_context>
escrow_id: ${context.escrow_id}
amount_usdc: ${context.amount}
audit_tier: ${context.tier}
${context.creator ? `creator: ${context.creator}` : ''}
${context.recipient ? `recipient: ${context.recipient}` : ''}
</escrow_context>`;
  }

  return [
    { role: 'system', content: ADVERSARIAL_AUDIT_PROMPT },
    { role: 'user', content: userContent }
  ];
}

/**
 * Build a minimal prompt for quick sanity checks (micro tier)
 */
export function buildQuickAuditMessages(strategyMemo: string): AuditMessage[] {
  const quickPrompt = `
You are a logic auditor. Evaluate this strategy memo for critical flaws.
Return JSON only: { "verdict": "PASS"|"FAIL", "risk_score": 0-100, "flags": [], "primary_flaw": "...", "summary": "..." }
FAIL if: circular logic, no exit criteria, no risk bounds, or relies purely on authority.
`.trim();

  return [
    { role: 'system', content: quickPrompt },
    { role: 'user', content: strategyMemo }
  ];
}

// ============================================================================
// RESPONSE PARSING
// ============================================================================

/**
 * Parse and validate Venice response
 * 
 * @param responseText - Raw response from Venice API
 * @returns Validated AuditResult
 * @throws Error if response is invalid
 */
export function parseAuditResponse(responseText: string): AuditResult {
  let text = responseText.trim();

  // Strip markdown code fences if present
  if (text.startsWith('```json')) {
    text = text.slice(7);
  } else if (text.startsWith('```')) {
    text = text.slice(3);
  }
  if (text.endsWith('```')) {
    text = text.slice(0, -3);
  }
  text = text.trim();

  // Parse JSON
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch (e) {
    throw new Error(`Venice returned invalid JSON: ${e instanceof Error ? e.message : 'Unknown error'}`);
  }

  // Validate with Zod
  const result = auditResultSchema.safeParse(parsed);
  if (!result.success) {
    const errors = result.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join(', ');
    throw new Error(`Invalid audit response: ${errors}`);
  }

  return result.data;
}

/**
 * Safe parse that returns null instead of throwing
 */
export function tryParseAuditResponse(responseText: string): AuditResult | null {
  try {
    return parseAuditResponse(responseText);
  } catch {
    return null;
  }
}

// ============================================================================
// HASH VERIFICATION
// ============================================================================

/**
 * Verify that plaintext memo hashes to the on-chain execution trace hash
 * 
 * @param strategyMemo - Plaintext strategy memo
 * @param onChainHash - Hash stored on-chain (from AuditPending event)
 * @returns true if hashes match
 */
export function verifyTraceHash(
  strategyMemo: string,
  onChainHash: `0x${string}`
): boolean {
  const computedHash = keccak256(toBytes(strategyMemo));
  return computedHash.toLowerCase() === onChainHash.toLowerCase();
}

/**
 * Compute the keccak256 hash of a strategy memo
 * Use this when submitting on-chain
 */
export function computeTraceHash(strategyMemo: string): `0x${string}` {
  return keccak256(toBytes(strategyMemo));
}

// ============================================================================
// LEGACY MAPPING
// ============================================================================

/**
 * Map new audit response to legacy format for backward compatibility
 */
export function mapToLegacyFormat(result: AuditResult): {
  primaryBiasDetected: string;
  logicFlaws: string[];
  structuralRecommendations: string[];
} {
  return {
    primaryBiasDetected: result.primary_flaw === 'None' ? 'None' : result.primary_flaw,
    logicFlaws: result.flags.map(f => `${f.code}: ${f.evidence}`),
    structuralRecommendations: result.flags.map(f => f.recommendation)
  };
}

// ============================================================================
// VERDICT HELPERS
// ============================================================================

/**
 * Extract abort-triggering flags from result
 */
export function getAbortTriggers(result: AuditResult): AuditFlag[] {
  const abortCodes = ['DJZS-S01', 'DJZS-S02', 'DJZS-X01', 'DJZS-E01', 'DJZS-E02', 'DJZS-X02', 'DJZS-T01'];
  return result.flags.filter(f => abortCodes.includes(f.code));
}

/**
 * Check if result should trigger auto-abort
 */
export function shouldAbort(result: AuditResult): boolean {
  if (result.verdict === 'FAIL') return true;
  if (result.risk_score >= 60) return true;
  if (getAbortTriggers(result).length > 0) return true;
  return false;
}

/**
 * Format result for logging
 */
export function formatResultForLog(result: AuditResult): string {
  const flagSummary = result.flags.length > 0
    ? result.flags.map(f => f.code).join(', ')
    : 'none';
  return `[${result.verdict}] risk=${result.risk_score} flags=[${flagSummary}] "${result.summary}"`;
}

// ============================================================================
// EXPORTS
// ============================================================================

export type {
  AuditFlag,
  AuditResult,
  EscrowContext
};
