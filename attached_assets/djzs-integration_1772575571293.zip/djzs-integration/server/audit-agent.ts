/**
 * DJZS Audit Agent
 * 
 * Main audit orchestration module. Coordinates:
 * - Venice AI adversarial analysis
 * - On-chain escrow state verification
 * - Irys certificate storage
 * - Settlement triggering
 * 
 * @module server/audit-agent
 */

import { randomUUID } from 'crypto';
import { createHash } from 'crypto';

import {
  AuditResult,
  AuditFlag,
  EscrowContext,
  ProofOfLogicCertificate,
  AuditTierType,
  AuditInput,
  auditInputSchema,
  TIER_CONFIG,
  shouldAutoAbort as shouldCodeAutoAbort,
  hasAutoAbortFlags
} from '../shared/audit-schema';

import {
  buildAuditMessages,
  parseAuditResponse,
  verifyTraceHash,
  computeTraceHash,
  mapToLegacyFormat,
  shouldAbort,
  formatResultForLog,
  getAbortTriggers
} from './adversarial-audit';

import { VeniceClient, getVeniceClient } from './venice';

// ============================================================================
// TYPES
// ============================================================================

export interface AuditExecutionInput {
  strategyMemo: string;
  tier: AuditTierType;
  targetSystem?: string;
  escrowId?: number;
  escrowContext?: EscrowContext;
  executionTraceHash?: `0x${string}`;  // For hash verification
}

export interface AuditExecutionResult {
  certificate: ProofOfLogicCertificate;
  shouldAbort: boolean;
  abortReasons: string[];
  rawResult: AuditResult;
}

// ============================================================================
// AUDIT EXECUTION
// ============================================================================

/**
 * Execute a full adversarial audit
 * 
 * This is the main entry point for auditing strategy memos.
 */
export async function executeAudit(
  input: AuditExecutionInput
): Promise<AuditExecutionResult> {
  const {
    strategyMemo,
    tier,
    targetSystem,
    escrowId,
    escrowContext,
    executionTraceHash
  } = input;

  const auditId = randomUUID();
  const timestamp = new Date().toISOString();

  console.log(`[Audit ${auditId}] Starting ${tier} audit for ${targetSystem || 'unknown'}`);

  // 1. Verify hash if provided
  if (executionTraceHash) {
    const hashValid = verifyTraceHash(strategyMemo, executionTraceHash);
    if (!hashValid) {
      throw new Error('Hash mismatch - strategy memo has been tampered');
    }
    console.log(`[Audit ${auditId}] Hash verification passed`);
  }

  // 2. Build escrow context
  const context: EscrowContext | undefined = escrowContext || (escrowId ? {
    escrow_id: escrowId,
    amount: 0,  // Would be fetched from on-chain
    tier
  } : undefined);

  // 3. Run Venice audit
  const venice = getVeniceClient();
  const rawResult = await venice.audit(strategyMemo, {
    tier,
    escrowContext: context,
    targetSystem
  });

  console.log(`[Audit ${auditId}] ${formatResultForLog(rawResult)}`);

  // 4. Determine abort triggers
  const abortTriggers = getAbortTriggers(rawResult);
  const abortReasons = abortTriggers.map(f => 
    `${f.code} (${f.severity}): ${f.evidence}`
  );
  const abort = shouldAbort(rawResult);

  // 5. Compute cryptographic hash of input
  const cryptographicHash = createHash('sha256')
    .update(strategyMemo)
    .digest('hex');

  // 6. Build certificate
  const certificate: ProofOfLogicCertificate = {
    audit_id: auditId,
    timestamp,
    tier,
    verdict: rawResult.verdict,
    risk_score: rawResult.risk_score,
    
    // New fields
    primary_flaw: rawResult.primary_flaw,
    summary: rawResult.summary,
    flags: rawResult.flags,
    
    // Legacy fields for backward compatibility
    ...mapToLegacyFormat(rawResult),
    
    // Provenance
    cryptographic_hash: cryptographicHash,
    provenance_provider: 'IRYS_DATACHAIN'
    // irys_tx_id and irys_url added after upload
  };

  return {
    certificate,
    shouldAbort: abort,
    abortReasons,
    rawResult
  };
}

// ============================================================================
// ESCROW AUDIT ENDPOINT HANDLER
// ============================================================================

export interface EscrowAuditRequest {
  escrow_id: number;
  agent_pubkey: string;
  strategy_memo: string;
  signature: string;
  timestamp?: number;
  proposed_action?: {
    target_contract: string;
    calldata: string;
  };
}

export interface EscrowAuditResponse {
  audit_verdict: 'PASS' | 'FAIL';
  risk_score: number;
  logic_hash: string;
  djzs_lf_flags: string[];
  irys_receipt: string;
  primary_flaw: string;
  summary: string;
}

/**
 * Handle escrow audit request (from API endpoint)
 * 
 * This is called by the /escrow/audit endpoint after:
 * 1. Payment verification (402 check)
 * 2. Escrow state verification (must be AUDIT_PENDING)
 * 3. Signature verification (proves sender is recipient)
 */
export async function handleEscrowAudit(
  request: EscrowAuditRequest,
  onChainHash: `0x${string}`,
  escrowState: {
    creator: string;
    recipient: string;
    amount: number;
    tier: AuditTierType;
  }
): Promise<EscrowAuditResponse> {
  
  // Verify hash matches
  if (!verifyTraceHash(request.strategy_memo, onChainHash)) {
    throw new Error('Hash mismatch - payload has been tampered');
  }

  // Build context
  const context: EscrowContext = {
    escrow_id: request.escrow_id,
    amount: escrowState.amount,
    tier: escrowState.tier,
    creator: escrowState.creator,
    recipient: escrowState.recipient
  };

  // Execute audit
  const result = await executeAudit({
    strategyMemo: request.strategy_memo,
    tier: escrowState.tier,
    escrowId: request.escrow_id,
    escrowContext: context,
    executionTraceHash: onChainHash
  });

  // Compute logic hash
  const logicHash = computeTraceHash(request.strategy_memo);

  // TODO: Upload to Irys
  const irisTxId = 'pending-irys-upload';

  return {
    audit_verdict: result.certificate.verdict,
    risk_score: result.certificate.risk_score,
    logic_hash: logicHash,
    djzs_lf_flags: result.certificate.flags.map(f => f.code),
    irys_receipt: irisTxId,
    primary_flaw: result.certificate.primary_flaw,
    summary: result.certificate.summary
  };
}

// ============================================================================
// SIMPLE API AUDIT (for non-escrow audits)
// ============================================================================

/**
 * Simple audit for direct API calls (not tied to escrow)
 */
export async function runSimpleAudit(
  input: AuditInput
): Promise<ProofOfLogicCertificate> {
  // Validate input
  const validated = auditInputSchema.parse(input);

  // Map audit_type to tier
  const tierMap: Record<string, AuditTierType> = {
    general: 'micro',
    strategy: 'founder',
    founder_drift: 'founder',
    treasury: 'treasury'
  };
  const tier = tierMap[validated.audit_type || 'general'] || 'micro';

  // Execute
  const result = await executeAudit({
    strategyMemo: validated.strategy_memo,
    tier,
    targetSystem: validated.target_system,
    escrowId: validated.escrow_id,
    escrowContext: validated.escrow_context
  });

  return result.certificate;
}

// ============================================================================
// AUDIT LOG MAPPING (for DB storage)
// ============================================================================

export interface AuditLogEntry {
  id: string;
  timestamp: Date;
  tier: string;
  verdict: string;
  riskScore: number;
  primaryBiasDetected: string;
  flagCodes: string[];
  flagCount: number;
  cryptographicHash: string;
  irisTxId?: string;
  targetSystem?: string;
}

/**
 * Map certificate to database log entry
 */
export function mapToAuditLog(
  certificate: ProofOfLogicCertificate,
  targetSystem?: string
): AuditLogEntry {
  return {
    id: certificate.audit_id,
    timestamp: new Date(certificate.timestamp),
    tier: certificate.tier,
    verdict: certificate.verdict,
    riskScore: certificate.risk_score,
    primaryBiasDetected: certificate.primary_flaw,
    flagCodes: certificate.flags.map(f => f.code),
    flagCount: certificate.flags.length,
    cryptographicHash: certificate.cryptographic_hash,
    irisTxId: certificate.irys_tx_id,
    targetSystem
  };
}

// ============================================================================
// AUTO-ABORT CHECKER
// ============================================================================

/**
 * Comprehensive auto-abort check including new codes
 */
export function shouldAutoAbortExecution(result: AuditResult): boolean {
  // Critical codes that always trigger abort
  const criticalCodes = [
    'DJZS-S01',  // CIRCULAR_LOGIC
    'DJZS-S02',  // MISSING_FALSIFIABILITY
    'DJZS-X01',  // UNHEDGED_EXECUTION
  ];

  // High severity codes that trigger abort
  const highCodes = [
    'DJZS-E01',  // CONFIRMATION_TUNNEL
    'DJZS-E02',  // AUTHORITY_SUBSTITUTION
    'DJZS-X02',  // LIQUIDITY_RISK
    'DJZS-T01',  // STALE_DATA_DEPENDENCY
  ];

  const allAbortCodes = [...criticalCodes, ...highCodes];

  // Check flags
  const hasAbortFlag = result.flags.some(f => allAbortCodes.includes(f.code));
  
  // Check risk score
  const highRisk = result.risk_score >= 60;
  
  // Check flag count
  const tooManyFlags = result.flags.length >= 3;

  return hasAbortFlag || highRisk || tooManyFlags;
}

// ============================================================================
// EXPORTS
// ============================================================================

export {
  verifyTraceHash,
  computeTraceHash,
  formatResultForLog
};
