/**
 * DJZS Oracle Server
 * 
 * Main entry point for the DJZS audit API.
 * 
 * @module server/index
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import router from './routes';
import { getVeniceClient } from './venice';

// ============================================================================
// CONFIGURATION
// ============================================================================

const PORT = process.env.PORT || 5000;
const NODE_ENV = process.env.NODE_ENV || 'development';

// ============================================================================
// APP SETUP
// ============================================================================

const app = express();

// Security headers
app.use(helmet());

// CORS
app.use(cors({
  origin: NODE_ENV === 'production' 
    ? ['https://djzs.ai', 'https://api.djzs.ai']
    : '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-payment-proof']
}));

// Body parsing
app.use(express.json({ limit: '1mb' }));

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
  });
  next();
});

// Routes
app.use(router);

// ============================================================================
// STARTUP
// ============================================================================

async function start() {
  console.log('='.repeat(60));
  console.log('DJZS ORACLE SERVER');
  console.log('='.repeat(60));
  console.log(`Environment: ${NODE_ENV}`);
  console.log(`Port: ${PORT}`);
  
  // Check Venice connectivity
  const venice = getVeniceClient();
  const veniceOk = await venice.ping();
  console.log(`Venice AI: ${veniceOk ? '✓ Connected' : '✗ Unavailable'}`);
  console.log(`Venice Model: ${venice.getModel()}`);
  
  // Start server
  app.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log(`Server running on port ${PORT}`);
    console.log(`Health: http://localhost:${PORT}/health`);
    console.log(`Agent manifest: http://localhost:${PORT}/.well-known/agent.json`);
    console.log('='.repeat(60));
  });
}

start().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

export default app;
