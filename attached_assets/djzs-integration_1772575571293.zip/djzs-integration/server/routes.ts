/**
 * DJZS API Routes
 * 
 * Express route handlers for the audit API.
 * 
 * @module server/routes
 */

import { Router, Request, Response, NextFunction } from 'express';
import { keccak256, toBytes } from 'viem';

import { 
  auditInputSchema, 
  escrowContextSchema,
  TIER_CONFIG,
  AuditTierType 
} from '../shared/audit-schema';

import {
  runSimpleAudit,
  handleEscrowAudit,
  executeAudit,
  EscrowAuditRequest
} from './audit-agent';

import { verifyTraceHash } from './adversarial-audit';

// ============================================================================
// ROUTER SETUP
// ============================================================================

const router = Router();

// ============================================================================
// MIDDLEWARE
// ============================================================================

/**
 * x402 Payment verification middleware
 * Checks escrow state on Base Mainnet before allowing audit
 */
async function verifyPayment(req: Request, res: Response, next: NextFunction) {
  const paymentProof = req.headers['x-payment-proof'] as string;
  const escrowId = req.body?.escrow_id;

  // Skip for non-escrow audits
  if (!escrowId) {
    return next();
  }

  if (!paymentProof) {
    return res.status(402).json({
      error: 'Payment Required',
      message: 'x-payment-proof header required for escrow audits'
    });
  }

  // TODO: Verify escrow state on-chain
  // const escrowState = await escrowContract.read.escrows([escrowId]);
  // if (escrowState.state !== 2) { // AUDIT_PENDING
  //   return res.status(402).json({ error: 'Escrow not in AUDIT_PENDING state' });
  // }

  next();
}

/**
 * Error handler wrapper
 */
function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// ============================================================================
// SIMPLE AUDIT ENDPOINTS (Non-escrow)
// ============================================================================

/**
 * POST /api/audit
 * Generic audit endpoint (backward compatible)
 */
router.post('/api/audit', asyncHandler(async (req: Request, res: Response) => {
  const input = auditInputSchema.parse(req.body);
  const certificate = await runSimpleAudit(input);
  res.json(certificate);
}));

/**
 * POST /api/audit/micro
 * Micro tier audit ($2.50)
 */
router.post('/api/audit/micro', asyncHandler(async (req: Request, res: Response) => {
  const { strategy_memo, target_system } = req.body;
  
  if (!strategy_memo || strategy_memo.length < 20) {
    return res.status(400).json({ error: 'strategy_memo required (min 20 chars)' });
  }

  const result = await executeAudit({
    strategyMemo: strategy_memo,
    tier: 'micro',
    targetSystem: target_system
  });

  res.json(result.certificate);
}));

/**
 * POST /api/audit/founder
 * Founder tier audit ($5.00)
 */
router.post('/api/audit/founder', asyncHandler(async (req: Request, res: Response) => {
  const { strategy_memo, target_system } = req.body;
  
  if (!strategy_memo || strategy_memo.length < 20) {
    return res.status(400).json({ error: 'strategy_memo required (min 20 chars)' });
  }

  if (strategy_memo.length > TIER_CONFIG.founder.memoLimit!) {
    return res.status(400).json({ 
      error: `strategy_memo exceeds founder tier limit of ${TIER_CONFIG.founder.memoLimit} chars` 
    });
  }

  const result = await executeAudit({
    strategyMemo: strategy_memo,
    tier: 'founder',
    targetSystem: target_system
  });

  res.json(result.certificate);
}));

/**
 * POST /api/audit/treasury
 * Treasury tier audit ($50.00)
 */
router.post('/api/audit/treasury', asyncHandler(async (req: Request, res: Response) => {
  const { strategy_memo, target_system } = req.body;
  
  if (!strategy_memo || strategy_memo.length < 20) {
    return res.status(400).json({ error: 'strategy_memo required (min 20 chars)' });
  }

  const result = await executeAudit({
    strategyMemo: strategy_memo,
    tier: 'treasury',
    targetSystem: target_system
  });

  res.json(result.certificate);
}));

// ============================================================================
// ESCROW AUDIT ENDPOINT (x402)
// ============================================================================

/**
 * POST /escrow/audit
 * Privacy-preserving escrow audit (x402 payment required)
 * 
 * Flow:
 * 1. Agent submits hash on-chain (submitForAudit)
 * 2. Agent calls this endpoint with plaintext
 * 3. TEE verifies hash matches
 * 4. TEE runs adversarial audit
 * 5. TEE settles on-chain
 */
router.post('/escrow/audit', verifyPayment, asyncHandler(async (req: Request, res: Response) => {
  const request: EscrowAuditRequest = req.body;

  // Validate required fields
  if (!request.escrow_id || !request.strategy_memo || !request.agent_pubkey) {
    return res.status(400).json({
      error: 'Missing required fields: escrow_id, strategy_memo, agent_pubkey'
    });
  }

  // TODO: Fetch on-chain escrow state and executionTraceHash
  // For now, compute the expected hash from the memo
  const expectedHash = keccak256(toBytes(request.strategy_memo)) as `0x${string}`;

  // TODO: Fetch actual escrow state from contract
  const mockEscrowState = {
    creator: '0x...',
    recipient: request.agent_pubkey,
    amount: 100e6,  // $100 USDC
    tier: 'founder' as AuditTierType
  };

  try {
    const response = await handleEscrowAudit(
      request,
      expectedHash,  // Would come from on-chain event
      mockEscrowState
    );

    res.json(response);
  } catch (error) {
    if (error instanceof Error && error.message.includes('Hash mismatch')) {
      return res.status(400).json({
        error: 'Hash Mismatch',
        message: 'The plaintext trace does not match the on-chain executionTraceHash'
      });
    }
    throw error;
  }
}));

// ============================================================================
// VERIFICATION ENDPOINT
// ============================================================================

/**
 * GET /api/audit/verify/:txId
 * Public certificate verification via Irys
 */
router.get('/api/audit/verify/:txId', asyncHandler(async (req: Request, res: Response) => {
  const { txId } = req.params;

  if (!txId || txId.length < 10) {
    return res.status(400).json({ error: 'Invalid transaction ID' });
  }

  try {
    // Fetch from Irys gateway
    const irysResponse = await fetch(`https://gateway.irys.xyz/${txId}`);
    
    if (!irysResponse.ok) {
      return res.status(404).json({
        verified: false,
        error: 'Certificate not found on Irys'
      });
    }

    const certificate = await irysResponse.json();

    res.json({
      verified: true,
      provenance_provider: 'IRYS_DATACHAIN',
      irys_tx_id: txId,
      irys_url: `https://gateway.irys.xyz/${txId}`,
      certificate: {
        audit_id: certificate.audit_id,
        timestamp: certificate.timestamp,
        tier: certificate.tier,
        verdict: certificate.verdict,
        risk_score: certificate.risk_score
      }
    });
  } catch (error) {
    res.status(500).json({
      verified: false,
      error: 'Failed to fetch certificate from Irys'
    });
  }
}));

// ============================================================================
// DISCOVERY ENDPOINTS
// ============================================================================

/**
 * GET /.well-known/agent.json
 * A2A agent discovery manifest
 */
router.get('/.well-known/agent.json', (req: Request, res: Response) => {
  res.json({
    name: 'DJZS Oracle',
    version: '1.0.0',
    description: 'Adversarial Logic Layer for the A2A economy',
    capabilities: ['audit', 'escrow-settlement', 'proof-of-logic'],
    endpoints: {
      audit: '/api/audit',
      escrow_audit: '/escrow/audit',
      verify: '/api/audit/verify/:txId',
      schema: '/api/audit/schema'
    },
    pricing: {
      micro: { amount: '2.50', currency: 'USDC', memo_limit: 1000 },
      founder: { amount: '5.00', currency: 'USDC', memo_limit: 5000 },
      treasury: { amount: '50.00', currency: 'USDC', memo_limit: null }
    },
    network: 'base-mainnet',
    settlement_token: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    provenance: 'IRYS_DATACHAIN'
  });
});

/**
 * GET /api/audit/schema
 * Full API schema
 */
router.get('/api/audit/schema', (req: Request, res: Response) => {
  res.json({
    version: '1.0.0',
    tiers: TIER_CONFIG,
    failure_codes: [
      'DJZS-S01', 'DJZS-S02',
      'DJZS-E01', 'DJZS-E02',
      'DJZS-I01', 'DJZS-I02',
      'DJZS-X01', 'DJZS-X02', 'DJZS-X03',
      'DJZS-T01', 'DJZS-T02'
    ],
    verdict_rules: {
      fail_conditions: [
        'CRITICAL flag detected (S01, S02, X01)',
        'HIGH flag detected (E01, E02, X02, T01)',
        'risk_score >= 60',
        '3 or more flags'
      ],
      pass_conditions: [
        'No CRITICAL or HIGH flags',
        'risk_score < 60',
        'Fewer than 3 flags',
        'Explicit exit criteria defined',
        'Risk bounds specified'
      ]
    }
  });
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

router.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    sys_id: 'djzs-mainnet-01'
  });
});

// ============================================================================
// ERROR HANDLER
// ============================================================================

router.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('[API Error]', err);

  // Zod validation errors
  if (err.name === 'ZodError') {
    return res.status(400).json({
      error: 'Validation Error',
      details: (err as any).issues
    });
  }

  // Generic error
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

export default router;
