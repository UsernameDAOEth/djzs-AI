/**
 * Venice AI Client
 * 
 * Handles communication with Venice AI API for adversarial logic auditing.
 * Runs inside Phala TEE for privacy-preserving inference.
 * 
 * @module server/venice
 */

import { 
  AuditResult, 
  EscrowContext,
  AuditTierType,
  TIER_CONFIG
} from '../shared/audit-schema';

import {
  ADVERSARIAL_AUDIT_PROMPT,
  buildAuditMessages,
  buildQuickAuditMessages,
  parseAuditResponse,
  AuditMessage
} from './adversarial-audit';

// ============================================================================
// CONFIGURATION
// ============================================================================

const VENICE_BASE_URL = process.env.VENICE_BASE_URL || 'https://api.venice.ai/api/v1';
const VENICE_API_KEY = process.env.VENICE_API_KEY;
const VENICE_MODEL = process.env.VENICE_MODEL || 'llama-3.3-70b';

// Deterministic output for reproducibility
const AUDIT_TEMPERATURE = 0;
const AUDIT_MAX_TOKENS = 2000;

// ============================================================================
// TYPES
// ============================================================================

export interface VeniceCompletionRequest {
  model: string;
  messages: AuditMessage[];
  temperature: number;
  max_tokens: number;
}

export interface VeniceCompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface AuditOptions {
  tier?: AuditTierType;
  escrowContext?: EscrowContext;
  targetSystem?: string;
}

// ============================================================================
// CLIENT CLASS
// ============================================================================

export class VeniceClient {
  private apiKey: string;
  private baseUrl: string;
  private model: string;

  constructor(
    apiKey?: string,
    baseUrl?: string,
    model?: string
  ) {
    this.apiKey = apiKey || VENICE_API_KEY || '';
    this.baseUrl = baseUrl || VENICE_BASE_URL;
    this.model = model || VENICE_MODEL;

    if (!this.apiKey) {
      console.warn('VeniceClient: No API key provided. Audit calls will fail.');
    }
  }

  /**
   * Run adversarial audit on a strategy memo
   * 
   * @param strategyMemo - The plaintext reasoning trace
   * @param options - Audit options (tier, escrow context)
   * @returns Validated AuditResult
   */
  async audit(
    strategyMemo: string,
    options: AuditOptions = {}
  ): Promise<AuditResult> {
    const { tier = 'micro', escrowContext, targetSystem } = options;

    // Validate memo length for tier
    const config = TIER_CONFIG[tier];
    if (config.memoLimit && strategyMemo.length > config.memoLimit) {
      throw new Error(
        `Memo exceeds ${tier} tier limit of ${config.memoLimit} characters`
      );
    }

    // Build context if escrow info provided
    const context: EscrowContext | undefined = escrowContext || (
      options.escrowContext ? {
        ...options.escrowContext,
        tier
      } : undefined
    );

    // Build messages
    const messages = tier === 'micro' && !escrowContext
      ? buildQuickAuditMessages(strategyMemo)
      : buildAuditMessages(strategyMemo, context);

    // Make API call
    const response = await this.chatCompletion(messages);

    // Parse and validate response
    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('Empty response from Venice');
    }

    return parseAuditResponse(content);
  }

  /**
   * Low-level chat completion call
   */
  async chatCompletion(messages: AuditMessage[]): Promise<VeniceCompletionResponse> {
    const url = `${this.baseUrl}/chat/completions`;

    const body: VeniceCompletionRequest = {
      model: this.model,
      messages,
      temperature: AUDIT_TEMPERATURE,
      max_tokens: AUDIT_MAX_TOKENS
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Venice API error ${response.status}: ${errorText}`);
    }

    return response.json() as Promise<VeniceCompletionResponse>;
  }

  /**
   * Health check
   */
  async ping(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/models`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * Get current model
   */
  getModel(): string {
    return this.model;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let veniceClientInstance: VeniceClient | null = null;

export function getVeniceClient(): VeniceClient {
  if (!veniceClientInstance) {
    veniceClientInstance = new VeniceClient();
  }
  return veniceClientInstance;
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Quick audit with default client
 */
export async function runAudit(
  strategyMemo: string,
  options?: AuditOptions
): Promise<AuditResult> {
  const client = getVeniceClient();
  return client.audit(strategyMemo, options);
}

/**
 * Get the raw system prompt (for debugging/transparency)
 */
export function getSystemPrompt(): string {
  return ADVERSARIAL_AUDIT_PROMPT;
}
