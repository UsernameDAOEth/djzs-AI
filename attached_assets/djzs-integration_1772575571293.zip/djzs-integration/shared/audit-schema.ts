/**
 * DJZS Audit Schema
 * 
 * Defines the complete DJZS-LF (Logic Failure) taxonomy, validation schemas,
 * and type definitions for the adversarial audit system.
 * 
 * Updated: Added T01, T02, X02, X03 codes per spec v1.0
 */

import { z } from 'zod';

// ============================================================================
// ENUMS & CONSTANTS
// ============================================================================

export const AuditTier = {
  MICRO: 'micro',
  FOUNDER: 'founder',
  TREASURY: 'treasury'
} as const;

export type AuditTierType = typeof AuditTier[keyof typeof AuditTier];

export const Severity = {
  CRITICAL: 'CRITICAL',
  HIGH: 'HIGH',
  MEDIUM: 'MEDIUM',
  LOW: 'LOW'
} as const;

export type SeverityType = typeof Severity[keyof typeof Severity];

export const Verdict = {
  PASS: 'PASS',
  FAIL: 'FAIL'
} as const;

export type VerdictType = typeof Verdict[keyof typeof Verdict];

// ============================================================================
// DJZS-LF FAILURE CODE TAXONOMY (Complete)
// ============================================================================

export const LOGIC_FAILURE_TAXONOMY = {
  // Structural Failures (CRITICAL - Auto-abort)
  'DJZS-S01': {
    code: 'DJZS-S01',
    category: 'Structural',
    name: 'CIRCULAR_LOGIC',
    severity: Severity.CRITICAL,
    autoAbort: true,
    description: 'The conclusion is embedded in the premise. The reasoning justifies itself without external validation.',
    riskPoints: 40
  },
  'DJZS-S02': {
    code: 'DJZS-S02',
    category: 'Structural',
    name: 'MISSING_FALSIFIABILITY',
    severity: Severity.CRITICAL,
    autoAbort: true,
    description: 'No conditions exist under which the strategy would be considered wrong.',
    riskPoints: 40
  },

  // Epistemic Failures (HIGH - Auto-abort)
  'DJZS-E01': {
    code: 'DJZS-E01',
    category: 'Epistemic',
    name: 'CONFIRMATION_TUNNEL',
    severity: Severity.HIGH,
    autoAbort: true,
    description: 'Selectively cites evidence supporting conclusion while ignoring contradictory data.',
    riskPoints: 25
  },
  'DJZS-E02': {
    code: 'DJZS-E02',
    category: 'Epistemic',
    name: 'AUTHORITY_SUBSTITUTION',
    severity: Severity.HIGH,
    autoAbort: true,
    description: 'Relies on authority rather than evaluating underlying logic.',
    riskPoints: 25
  },

  // Incentive Failures (MEDIUM - Review required)
  'DJZS-I01': {
    code: 'DJZS-I01',
    category: 'Incentive',
    name: 'MISALIGNED_INCENTIVE',
    severity: Severity.MEDIUM,
    autoAbort: false,
    description: 'Incentives of referenced parties conflict with agent goals.',
    riskPoints: 10
  },
  'DJZS-I02': {
    code: 'DJZS-I02',
    category: 'Incentive',
    name: 'NARRATIVE_DEPENDENCY',
    severity: Severity.MEDIUM,
    autoAbort: false,
    description: 'Success depends on a narrative remaining true with no hedge.',
    riskPoints: 10
  },

  // Execution Failures (Mixed severity)
  'DJZS-X01': {
    code: 'DJZS-X01',
    category: 'Execution',
    name: 'UNHEDGED_EXECUTION',
    severity: Severity.CRITICAL,
    autoAbort: true,
    description: 'No risk bounds defined. Unlimited downside exposure.',
    riskPoints: 40
  },
  'DJZS-X02': {
    code: 'DJZS-X02',
    category: 'Execution',
    name: 'LIQUIDITY_RISK',
    severity: Severity.HIGH,
    autoAbort: true,
    description: 'Strategy assumes liquidity that may not exist.',
    riskPoints: 25
  },
  'DJZS-X03': {
    code: 'DJZS-X03',
    category: 'Execution',
    name: 'SLIPPAGE_EXPOSURE',
    severity: Severity.MEDIUM,
    autoAbort: false,
    description: 'Strategy ignores execution costs that could erode returns.',
    riskPoints: 10
  },

  // Temporal Failures (NEW)
  'DJZS-T01': {
    code: 'DJZS-T01',
    category: 'Temporal',
    name: 'STALE_DATA_DEPENDENCY',
    severity: Severity.HIGH,
    autoAbort: true,
    description: 'Strategy relies on data that may no longer be current.',
    riskPoints: 25
  },
  'DJZS-T02': {
    code: 'DJZS-T02',
    category: 'Temporal',
    name: 'RACE_CONDITION_RISK',
    severity: Severity.MEDIUM,
    autoAbort: false,
    description: 'Strategy assumes sequential execution but could be front-run.',
    riskPoints: 10
  }
} as const;

export type LogicFailureCode = keyof typeof LOGIC_FAILURE_TAXONOMY;

// All valid codes as array (for validation)
export const VALID_FAILURE_CODES = Object.keys(LOGIC_FAILURE_TAXONOMY) as LogicFailureCode[];

// Codes that trigger auto-abort
export const AUTO_ABORT_CODES: LogicFailureCode[] = Object.entries(LOGIC_FAILURE_TAXONOMY)
  .filter(([_, def]) => def.autoAbort)
  .map(([code]) => code as LogicFailureCode);

// ============================================================================
// ZOD SCHEMAS
// ============================================================================

// Flexible code schema - accepts known codes but allows extensions
export const logicFailureCodeSchema = z.string().refine(
  (code) => code.startsWith('DJZS-'),
  { message: 'Logic failure code must start with DJZS-' }
);

export const severitySchema = z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']);

export const verdictSchema = z.enum(['PASS', 'FAIL']);

export const auditTierSchema = z.enum(['micro', 'founder', 'treasury']);

// Individual flag from Venice response
export const auditFlagSchema = z.object({
  code: logicFailureCodeSchema,
  severity: severitySchema,
  evidence: z.string().min(1),
  recommendation: z.string().min(1)
});

export type AuditFlag = z.infer<typeof auditFlagSchema>;

// Complete audit result from Venice
export const auditResultSchema = z.object({
  verdict: verdictSchema,
  risk_score: z.number().min(0).max(100),
  flags: z.array(auditFlagSchema),
  primary_flaw: z.string(),
  summary: z.string().min(1)
});

export type AuditResult = z.infer<typeof auditResultSchema>;

// Escrow context for audit requests
export const escrowContextSchema = z.object({
  escrow_id: z.number().int().positive(),
  amount: z.number().positive(),
  tier: auditTierSchema,
  creator: z.string().optional(),
  recipient: z.string().optional()
});

export type EscrowContext = z.infer<typeof escrowContextSchema>;

// Audit input (what the API receives)
export const auditInputSchema = z.object({
  strategy_memo: z.string().min(20, 'Strategy memo must be at least 20 characters'),
  audit_type: z.enum(['treasury', 'founder_drift', 'strategy', 'general']).optional().default('general'),
  target_system: z.string().optional(),
  escrow_id: z.number().int().positive().optional(),
  escrow_context: escrowContextSchema.optional()
});

export type AuditInput = z.infer<typeof auditInputSchema>;

// ProofOfLogic certificate (what we store/return)
export const proofOfLogicCertificateSchema = z.object({
  audit_id: z.string().uuid(),
  timestamp: z.string().datetime(),
  tier: auditTierSchema,
  verdict: verdictSchema,
  risk_score: z.number().min(0).max(100),
  
  // New fields from adversarial audit
  primary_flaw: z.string(),
  summary: z.string(),
  flags: z.array(auditFlagSchema),
  
  // Legacy fields (optional for backward compat)
  primary_bias_detected: z.string().optional(),
  logic_flaws: z.array(z.string()).optional(),
  structural_recommendations: z.array(z.string()).optional(),
  
  // Provenance
  cryptographic_hash: z.string(),
  provenance_provider: z.literal('IRYS_DATACHAIN'),
  irys_tx_id: z.string().optional(),
  irys_url: z.string().url().optional()
});

export type ProofOfLogicCertificate = z.infer<typeof proofOfLogicCertificateSchema>;

// ============================================================================
// TIER CONFIGURATION
// ============================================================================

export const TIER_CONFIG = {
  micro: {
    name: 'Micro',
    priceUSDC: 2.5,
    memoLimit: 1000,
    useCase: 'Operational sanity checks, binary risk scoring',
    consensusRequired: false
  },
  founder: {
    name: 'Founder',
    priceUSDC: 5.0,
    memoLimit: 5000,
    useCase: 'Strategic roadmap diligence, narrative drift detection',
    consensusRequired: false
  },
  treasury: {
    name: 'Treasury',
    priceUSDC: 50.0,
    memoLimit: null, // Unlimited
    useCase: 'Exhaustive adversarial stress-test for capital deployment',
    consensusRequired: true
  }
} as const;

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Check if a code triggers auto-abort
 */
export function shouldAutoAbort(code: string): boolean {
  return AUTO_ABORT_CODES.includes(code as LogicFailureCode);
}

/**
 * Check if any flags in result trigger auto-abort
 */
export function hasAutoAbortFlags(flags: AuditFlag[]): boolean {
  return flags.some(flag => shouldAutoAbort(flag.code));
}

/**
 * Get risk points for a code
 */
export function getRiskPoints(code: string): number {
  const def = LOGIC_FAILURE_TAXONOMY[code as LogicFailureCode];
  return def?.riskPoints ?? 10; // Default to MEDIUM if unknown code
}

/**
 * Calculate risk score from flags
 */
export function calculateRiskScore(flags: AuditFlag[]): number {
  if (flags.length === 0) return 0;
  
  let score = 0;
  flags.forEach((flag, index) => {
    score += getRiskPoints(flag.code);
    if (index > 0) score += 5; // Additional flag penalty
  });
  
  return Math.min(score, 100);
}

/**
 * Determine verdict based on flags and risk score
 */
export function determineVerdict(flags: AuditFlag[], riskScore: number): VerdictType {
  // FAIL conditions
  if (hasAutoAbortFlags(flags)) return Verdict.FAIL;
  if (riskScore >= 60) return Verdict.FAIL;
  if (flags.length >= 3) return Verdict.FAIL;
  
  // PASS conditions (all must be true)
  const hasCriticalOrHigh = flags.some(f => 
    f.severity === 'CRITICAL' || f.severity === 'HIGH'
  );
  if (hasCriticalOrHigh) return Verdict.FAIL;
  
  return Verdict.PASS;
}

/**
 * Get failure definition by code
 */
export function getFailureDefinition(code: string) {
  return LOGIC_FAILURE_TAXONOMY[code as LogicFailureCode] ?? null;
}

/**
 * Validate tier memo length
 */
export function validateMemoLength(memo: string, tier: AuditTierType): boolean {
  const config = TIER_CONFIG[tier];
  if (config.memoLimit === null) return true;
  return memo.length <= config.memoLimit;
}
