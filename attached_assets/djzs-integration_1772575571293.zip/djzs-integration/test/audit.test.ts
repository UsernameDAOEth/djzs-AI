/**
 * DJZS Integration Tests
 * 
 * Run: npx ts-node test/audit.test.ts
 */

import {
  parseAuditResponse,
  verifyTraceHash,
  computeTraceHash,
  mapToLegacyFormat,
  shouldAbort,
  buildAuditMessages
} from '../server/adversarial-audit';

import {
  auditResultSchema,
  shouldAutoAbort,
  calculateRiskScore,
  determineVerdict,
  AuditFlag
} from '../shared/audit-schema';

// ============================================================================
// TEST HELPERS
// ============================================================================

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void) {
  try {
    fn();
    console.log(`✓ ${name}`);
    passed++;
  } catch (e) {
    console.log(`✗ ${name}`);
    console.log(`  Error: ${e instanceof Error ? e.message : e}`);
    failed++;
  }
}

function assert(condition: boolean, message: string) {
  if (!condition) throw new Error(message);
}

function assertEqual<T>(actual: T, expected: T, message: string) {
  if (actual !== expected) {
    throw new Error(`${message}: expected ${expected}, got ${actual}`);
  }
}

// ============================================================================
// TESTS
// ============================================================================

console.log('\n=== DJZS Integration Tests ===\n');

// Test: Parse valid PASS response
test('parseAuditResponse: valid PASS', () => {
  const response = `{
    "verdict": "PASS",
    "risk_score": 15,
    "flags": [],
    "primary_flaw": "None",
    "summary": "Strategy has explicit risk bounds."
  }`;
  
  const result = parseAuditResponse(response);
  assertEqual(result.verdict, 'PASS', 'verdict');
  assertEqual(result.risk_score, 15, 'risk_score');
  assertEqual(result.flags.length, 0, 'flags length');
});

// Test: Parse valid FAIL response
test('parseAuditResponse: valid FAIL with flags', () => {
  const response = `{
    "verdict": "FAIL",
    "risk_score": 75,
    "flags": [
      {
        "code": "DJZS-S01",
        "severity": "CRITICAL",
        "evidence": "Strategy justifies itself",
        "recommendation": "Add external validation"
      }
    ],
    "primary_flaw": "Circular logic detected",
    "summary": "Strategy lacks falsifiability."
  }`;
  
  const result = parseAuditResponse(response);
  assertEqual(result.verdict, 'FAIL', 'verdict');
  assertEqual(result.risk_score, 75, 'risk_score');
  assertEqual(result.flags.length, 1, 'flags length');
  assertEqual(result.flags[0].code, 'DJZS-S01', 'flag code');
});

// Test: Strip markdown fences
test('parseAuditResponse: strips markdown fences', () => {
  const response = '```json\n{"verdict":"PASS","risk_score":0,"flags":[],"primary_flaw":"None","summary":"OK"}\n```';
  const result = parseAuditResponse(response);
  assertEqual(result.verdict, 'PASS', 'verdict');
});

// Test: Reject invalid JSON
test('parseAuditResponse: rejects invalid JSON', () => {
  try {
    parseAuditResponse('not json');
    throw new Error('Should have thrown');
  } catch (e) {
    assert(e instanceof Error && e.message.includes('invalid JSON'), 'should throw invalid JSON error');
  }
});

// Test: Hash computation
test('computeTraceHash: computes keccak256', () => {
  const hash = computeTraceHash('test memo');
  assert(hash.startsWith('0x'), 'hash should start with 0x');
  assertEqual(hash.length, 66, 'hash should be 66 chars');
});

// Test: Hash verification
test('verifyTraceHash: verifies matching hash', () => {
  const memo = 'test strategy memo';
  const hash = computeTraceHash(memo);
  assert(verifyTraceHash(memo, hash), 'should verify matching hash');
});

// Test: Hash verification fails on mismatch
test('verifyTraceHash: rejects mismatched hash', () => {
  const memo = 'test strategy memo';
  const wrongHash = '0x0000000000000000000000000000000000000000000000000000000000000000' as `0x${string}`;
  assert(!verifyTraceHash(memo, wrongHash), 'should reject mismatched hash');
});

// Test: Auto-abort detection
test('shouldAutoAbort: detects critical codes', () => {
  assert(shouldAutoAbort('DJZS-S01'), 'S01 should abort');
  assert(shouldAutoAbort('DJZS-S02'), 'S02 should abort');
  assert(shouldAutoAbort('DJZS-X01'), 'X01 should abort');
  assert(shouldAutoAbort('DJZS-E01'), 'E01 should abort');
});

// Test: Non-abort codes
test('shouldAutoAbort: allows medium codes', () => {
  assert(!shouldAutoAbort('DJZS-I01'), 'I01 should not abort');
  assert(!shouldAutoAbort('DJZS-I02'), 'I02 should not abort');
  assert(!shouldAutoAbort('DJZS-X03'), 'X03 should not abort');
});

// Test: Risk score calculation
test('calculateRiskScore: calculates correctly', () => {
  const flags: AuditFlag[] = [
    { code: 'DJZS-S01', severity: 'CRITICAL', evidence: '', recommendation: '' }
  ];
  const score = calculateRiskScore(flags);
  assertEqual(score, 40, 'single CRITICAL = 40');
});

// Test: Risk score with multiple flags
test('calculateRiskScore: adds penalty for multiple flags', () => {
  const flags: AuditFlag[] = [
    { code: 'DJZS-S01', severity: 'CRITICAL', evidence: '', recommendation: '' },
    { code: 'DJZS-E01', severity: 'HIGH', evidence: '', recommendation: '' }
  ];
  const score = calculateRiskScore(flags);
  assertEqual(score, 70, 'CRITICAL + HIGH + penalty = 70');
});

// Test: Verdict determination
test('determineVerdict: FAIL on critical', () => {
  const flags: AuditFlag[] = [
    { code: 'DJZS-S01', severity: 'CRITICAL', evidence: '', recommendation: '' }
  ];
  assertEqual(determineVerdict(flags, 40), 'FAIL', 'critical should fail');
});

// Test: Verdict determination - PASS
test('determineVerdict: PASS on clean', () => {
  const flags: AuditFlag[] = [];
  assertEqual(determineVerdict(flags, 0), 'PASS', 'clean should pass');
});

// Test: Build audit messages
test('buildAuditMessages: includes strategy memo', () => {
  const messages = buildAuditMessages('test memo');
  assertEqual(messages.length, 2, 'should have 2 messages');
  assertEqual(messages[0].role, 'system', 'first should be system');
  assert(messages[1].content.includes('test memo'), 'should include memo');
});

// Test: Build audit messages with context
test('buildAuditMessages: includes escrow context', () => {
  const messages = buildAuditMessages('test memo', {
    escrow_id: 42,
    amount: 100,
    tier: 'founder'
  });
  assert(messages[1].content.includes('escrow_id: 42'), 'should include escrow_id');
  assert(messages[1].content.includes('amount_usdc: 100'), 'should include amount');
});

// Test: Legacy mapping
test('mapToLegacyFormat: maps correctly', () => {
  const result = {
    verdict: 'FAIL' as const,
    risk_score: 50,
    flags: [
      { code: 'DJZS-S01', severity: 'CRITICAL' as const, evidence: 'circular', recommendation: 'fix it' }
    ],
    primary_flaw: 'Circular logic',
    summary: 'Bad strategy'
  };
  
  const legacy = mapToLegacyFormat(result);
  assertEqual(legacy.primaryBiasDetected, 'Circular logic', 'primaryBiasDetected');
  assertEqual(legacy.logicFlaws.length, 1, 'logicFlaws length');
  assertEqual(legacy.structuralRecommendations.length, 1, 'recommendations length');
});

// Test: shouldAbort helper
test('shouldAbort: true on FAIL', () => {
  const result = {
    verdict: 'FAIL' as const,
    risk_score: 50,
    flags: [],
    primary_flaw: 'test',
    summary: 'test'
  };
  assert(shouldAbort(result), 'FAIL should abort');
});

// Test: shouldAbort on high risk
test('shouldAbort: true on high risk', () => {
  const result = {
    verdict: 'PASS' as const,
    risk_score: 65,
    flags: [],
    primary_flaw: 'None',
    summary: 'test'
  };
  assert(shouldAbort(result), 'high risk should abort');
});

// ============================================================================
// SUMMARY
// ============================================================================

console.log('\n' + '='.repeat(40));
console.log(`Tests: ${passed + failed} | Passed: ${passed} | Failed: ${failed}`);
console.log('='.repeat(40) + '\n');

process.exit(failed > 0 ? 1 : 0);
